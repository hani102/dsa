//NAME: HANI SHAH
// ROLL NO L1S21BSCS0177
//section: D5
#include <iostream>
using namespace std;
#ifndef INTOPOS_H
#define INTOPOS_H

#include <string>

class Intopos {
private:
    char a;
    char b;
    char c;
    std::string d;

public:
    Intopos();
    Intopos(char a, char b, char c, string d);
    string convert();
};

#endif