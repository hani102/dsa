//NAME: HANI SHAH
// ROLL NO L1S21BSCS0177
//section: D5

#include "string.h"
#include <string>
#include <vector>

using namespace std;

Intopos::Intopos() {}

Intopos::Intopos(char a, char b, char c, string d) {
    this->a = a;
    this->b = b;
    this->c = c;
    this->d = d;
}

string Intopos::convert() {
    string postfix;
    vector<char> stack;
    int n = d.size();

    for (int i = 0; i < n; i++) {
        if (d[i] == '(') {
            stack.push_back(d[i]);
        }
        else if (d[i] == ')') {
            while (!stack.empty() && stack.back() != '(') {
                postfix += stack.back();
                stack.pop_back();
            }
            stack.pop_back();
        }
        else if (isalpha(d[i])) {
            postfix += d[i];
        }
        else {
            while (!stack.empty() && stack.back() != '(' && ((d[i] == '^' && stack.back() == '^') || (d[i] != '^' && d[i] == '*' && stack.back() == '/') || (d[i] == '+' && stack.back() == '-'))) {
                postfix += stack.back();
                stack.pop_back();
            }
            stack.push_back(d[i]);
        }
    }

    while (!stack.empty()) {
        postfix += stack.back();
        stack.pop_back();
    }

    return postfix;
}
