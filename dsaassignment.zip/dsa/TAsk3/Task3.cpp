//NAME: HANI SHAH
// ROLL NO L1S21BSCS0177
//section: D5

#include <iostream>
#include "Task3.h"

using namespace std;

int main() {
    string str = "a+b*(c^d-e)^(f+g*h)-i";
    Intopos intopos('a', 'b', 'c', str);
    string postfix = intopos.convert();
    cout << postfix << endl;
    system("pause");
    return 0;
}
