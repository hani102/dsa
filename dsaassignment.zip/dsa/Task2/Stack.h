//L1S21BSCS0177
//NAME: HANI SHAH
//SECTION : D5
#include <vector>

class Stack {

	int * arr;
	int size;
	int topone;
	int toptwo;

public:
	Stack(int);
	void push1(int);
	void push2(int);
	int pop1();
	int pop2();






};