//NAME: HANI SHAH
//ROLL NO. L1S21BSCS0177
// SECTION D5


#include "Task2.h"
int main() {
    Stack s(5);

    s.push1(2);
    s.push1(3);
    s.push2(4);

    cout << s.pop1() << endl;
    cout << s.pop2() << endl;
    cout << s.pop2() << endl;

    return 0;
}




