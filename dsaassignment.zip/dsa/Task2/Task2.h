// L1S21BSCS0177
//NAME: HANI SHAH
//SECTION : D5

#include <iostream>
#include "Stack.h"
#include <vector>
using namespace std;



Stack::Stack(int n) {
    size = n;
    arr = new int[size];
    topone = -1;
    toptwo = size;
}

void Stack::push1(int v) {
    if (topone < toptwo - 1) {
        topone++;
        arr[topone] = v;
    }
    else {
        cout << "Stack is overflowing" << endl;
        exit(1);
    }

}
void Stack::push2(int h) {

    if (topone < toptwo - 1) {
        toptwo--;
        arr[toptwo] = h;
    }
    else {
        cout << "Stack Overflow\n";
        exit(1);
    }





}
int Stack::pop1() {

    if (topone >= 0) {
        int x = arr[topone];
        topone--;
        return x;
    }
    else {
        cout << "Stack Underflowing " << endl;
        exit(1);
    }



}

int Stack::pop2() {

    if (toptwo < size) {
        int x = arr[toptwo];
        toptwo++;
        return x;
    }
    else {
        cout << "Stack Underflow\n";
        exit(1);
    }
}




