//Name: Hani Shah
//ROLL NO. L1S21BSCS0177
//SECTION: D5
#include "Task1.h"

using namespace std;

int main() {
    int arru[10] = { 1, 3, 2, 8, 8, 3, 7, 4, 4, 6 };
    ArrayUtility util(arru, 0, 9);

    util.findMax(arru, 2, 7); 
    util.findMaxPos(arru, 2, 7); 
    util.findMin(arru, 2, 7); 
    util.findMinPos(arru, 2, 7); 

    util.swap(arru, 2, 7); 

    util.shiftRight(arru, 3, 8); 
    util.shiftLeft(arru, 2, 7); 
    system("pause");
    return 0;
}