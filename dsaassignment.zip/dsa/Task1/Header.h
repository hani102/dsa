//Name: Hani Shah
//ROLL NO. L1S21BSCS0177
//SECTION: D5


class ArrayUtility {

private:
	int ar[10];
	int a;
	int b;

public:
	ArrayUtility(int[], int, int);
	void findMax(int[], int, int);
	void findMaxPos(int[], int, int);
	void findMin(int[], int, int);
	void findMinPos(int[], int, int);
	void swap(int[], int, int);
	void shiftRight(int[], int, int);
	void shiftLeft(int[], int, int);










};