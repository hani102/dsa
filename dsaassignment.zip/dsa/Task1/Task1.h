//Name: Hani Shah
//ROLL NO. L1S21BSCS0177
//SECTION: D5
#include "Header.h"
#include <iostream>
using namespace std;



ArrayUtility::ArrayUtility(int q[10], int n, int m) {
    int i = 0;
    while (i < 10) {
        ar[i] = q[i];
        i++;
    }
    b = m;
    a = n;
}

void ArrayUtility::findMax(int q[], int n, int m) {
    int maxVal1 = q[n];
    int k = n + 1;
    while (k <= m) {
        if (q[k] > maxVal1) {
            maxVal1 = q[k];
        }
        k++;
    }
    cout << "The maximum value between positions " << n << " and " << m << " is: " << maxVal1 << endl;
}

void ArrayUtility::findMaxPos(int A[], int n, int m) {
    int maxPos = n;
    int k = n + 1;
    while (k <= m) {
        if (A[k] > A[maxPos]) {
            maxPos = k;
        }
        k++;
    }
    cout << "The maximum value in the array between position " << n << " and position " << m << " is " << A[maxPos] << ", and it occurs at position " << maxPos << "." << endl;
}

void ArrayUtility::findMin(int A[], int n, int m) {
    int maxVal1 = ar[n];
    int k = n + 1;
    while (k <= m) {
        if (ar[k] > maxVal1) {
            maxVal1 = ar[k];
        }
        k++;
    }
    cout << "The maximum value between positions " << n << " and " << m << " is: " << maxVal1 << endl;
}

void ArrayUtility::findMinPos(int A[], int n, int m) {
    int minPos = n;
    int k = n + 1;
    while (k <= m) {
        if (A[k] < A[minPos]) {
            minPos = k;
        }
        k++;
    }
    std::cout << "The minimum value in A between position " << n << " and " << m << " is " << A[minPos] << " at position " << minPos << std::endl;
}

void ArrayUtility::swap(int A[], int n, int m) {
    int temp = A[n];
    A[n] = A[m];
    A[m] = temp;
    cout << "Swapped elements at positions " << n << " and " << m << std::endl;
}

void ArrayUtility:: shiftRight(int A[], int i, int j) {
    while (j > i) {
        A[j] = A[j - 1];
        std::cout << "Shifted element at position " << j - 1 << " to position " << j << std::endl;
        j--;
    }
}

void ArrayUtility::shiftLeft(int A[], int i, int j) {
    while (i < j) {
        A[i] = A[i + 1];
        cout << "Shifted element at position " << i + 1 << " to position " << i << std::endl;
        i++;
    }
}

